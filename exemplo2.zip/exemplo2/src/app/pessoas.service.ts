import { Injectable } from '@angular/core';
import { PESSOAS } from './mock-pessoas';
import { Pessoas } from './pessoas';

@Injectable({
  providedIn: 'root'
})
export class PessoasService {

  constructor() {
    this.getPessoasDatabase();
  }

  getPessoasDatabase(){
    var session = sessionStorage.getItem('pessoas');
    console.log(session);
    if(session === null){
      this.lpessoa = PESSOAS
      sessionStorage.setItem('pessoas',JSON.stringify(this.lpessoa))
    }else{
      this.lpessoa = JSON.parse(session)
    }
  }

  lpessoa: Pessoas[];

  getAll(): Pessoas[]{
    return this.lpessoa;
  }

  getById(id: number){
    return this.lpessoa[id-1]
  }

  getLastid(){
    return this.lpessoa[this.getQtd()-1].id
  }

  getQtd(){
    return this.lpessoa.length
  }

  getNextId(){
    return this.getLastid()+1
  }

  add(pessoa){
    this.lpessoa.push(pessoa)
    sessionStorage.setItem('pessoas',JSON.stringify(this.lpessoa))
  }

}
