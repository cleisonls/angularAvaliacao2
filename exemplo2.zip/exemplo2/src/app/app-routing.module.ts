import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListarPessoasComponent } from './listar-pessoas/listar-pessoas.component';
import { DetalhesComponent } from './detalhes/detalhes.component';
import { HomeComponent } from './home/home.component';
import { ListarCarrosComponent } from './listar-carros/listar-carros.component';
import { DetalhesCarrosComponent } from './detalhes-carros/detalhes-carros.component';


const routes: Routes = [
  {path:'', component: HomeComponent},
  {path:'pessoas', component: ListarPessoasComponent},
  {path:'pessoas/:idpessoa', component: DetalhesComponent},
  {path:'carros/:idcarro', component: DetalhesCarrosComponent},
  {path:'carros', component: ListarCarrosComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
