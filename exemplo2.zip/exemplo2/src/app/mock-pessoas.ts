import { Pessoas } from "./pessoas";

export const PESSOAS: Pessoas[] = [
    {
        id: 1,
        nome: 'Virgilio',
        dataNascimento: '01-01-2001',
        idade: 12,
        cidade: 'Nova iguaçu',
        uf: 'RJ',
        empregado: true,
        altura: 1.77

    },
    {
        id: 2,
        nome: 'Cleison',
        dataNascimento: '05-08-1998',
        idade: 21,
        cidade: 'Mesquita',
        uf: 'rj',
        empregado: true,
        altura: 1.77
    },
];