import { Component, OnInit } from '@angular/core';
import { Pessoas } from '../pessoas';
import { ActivatedRoute } from '@angular/router';
import { PESSOAS } from '../mock-pessoas';
import { PessoasService } from '../pessoas.service';

@Component({
  selector: 'app-detalhes',
  templateUrl: './detalhes.component.html',
  styleUrls: ['./detalhes.component.css']
})
export class DetalhesComponent implements OnInit {

  pessoa = new Pessoas()
  idpessoa: any 
  pessoas: any

  constructor(private route: ActivatedRoute, private PessoasService: PessoasService) {
    this.idpessoa = this.route.snapshot.params['idpessoa'];
    this.pessoas = PESSOAS
    var pessoa = this.PessoasService.getById(this.idpessoa);

    if(pessoa !== undefined){
      this.pessoa = pessoa
    }
  }

  ngOnInit() {
  }

  getGetParams() {
    return this.route.snapshot.queryParams;
  }
  
}

