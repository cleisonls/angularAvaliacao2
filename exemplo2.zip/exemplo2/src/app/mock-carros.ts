import { Carros } from "./carros";

export const CARROS: Carros[] = [
    { 
        id: 1,
        marca: 'Fiat',
        modelo: 'Palio',
        ano: '2010',
        placa: 'abc1d234',
    },
    {
        id: 2,
        marca: 'Chevrolet',
        modelo: 'Onix',
        ano: '2010',
        placa: 'uhg4d12',
    },
];