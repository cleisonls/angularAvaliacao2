import { Component, OnInit } from '@angular/core';
import { PESSOAS } from '../mock-pessoas';
import { PessoasService } from '../pessoas.service';
import { CARROS } from '../mock-carros';
import { CarrosService } from '../carros.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  lpessoas = PESSOAS;
  qtdPessoas() {
    return this.PessoasService.getQtd()
  }

  qtdCarros() {
    return this.CarrosService.getQtd()
  }

  constructor(private PessoasService:PessoasService,private CarrosService:CarrosService) { }

  ngOnInit() {
  }

}
