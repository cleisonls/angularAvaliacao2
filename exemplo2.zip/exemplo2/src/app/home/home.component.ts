import { Component, OnInit } from '@angular/core';
import { PESSOAS } from '../mock-pessoas';
import { PessoasService } from '../pessoas.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  lpessoas = PESSOAS;
  qtdPessoas() {
    return this.PessoasService.getQtd()
  }

  constructor(private PessoasService:PessoasService) { }

  ngOnInit() {
  }

}
