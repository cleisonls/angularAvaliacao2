export class Pessoas {
    id: number;
    nome: string;
    dataNascimento: string;
    idade: number;
    cidade: string;
    uf: string;
    empregado: boolean;
    altura?: number;
}