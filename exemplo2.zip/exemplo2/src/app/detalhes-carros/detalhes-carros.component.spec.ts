import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalhesCarrosComponent } from './detalhes-carros.component';

describe('DetalhesCarrosComponent', () => {
  let component: DetalhesCarrosComponent;
  let fixture: ComponentFixture<DetalhesCarrosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetalhesCarrosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetalhesCarrosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
