import { Component, OnInit } from '@angular/core';
import { Carros } from '../carros';
import { CarrosService } from '../carros.service';

@Component({
  selector: 'app-listar-carros',
  templateUrl: './listar-carros.component.html',
  styleUrls: ['./listar-carros.component.css']
})
export class ListarCarrosComponent implements OnInit {
  carro : Carros = {
    id: 0,
    marca:'',
    modelo:'',
    ano: '',
    placa:''
  };
  

  constructor(private CarrosService: CarrosService) {
    this.carro.id = this.CarrosService.getNextId();
  } 

  ngOnInit() {
  }

  carros = this.CarrosService.getAll()

  onAdd(): void {
    this.CarrosService.add(this.carro)
    this.limpar()
  }

  limpar(): void {
    this.carro = new Carros();
    let number = this.CarrosService.getNextId()
    this.carro.id = number;
  }
  
}
