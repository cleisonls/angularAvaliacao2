import { Injectable } from '@angular/core';
import { CARROS } from './mock-carros';
import { Carros } from './carros';

@Injectable({
  providedIn: 'root'
})
export class CarrosService {

  constructor() {
    this.getCarrosDatabase();
  }

  getCarrosDatabase(){
    var sessionCarros = sessionStorage.getItem('carros');
    console.log(sessionCarros);
    if(sessionCarros === null){
      this.receberCarros = CARROS
      sessionStorage.setItem('carros',JSON.stringify(this.receberCarros))
    }else{
      this.receberCarros = JSON.parse(sessionCarros)
    }
  }

  receberCarros: Carros[];

  getAll(): Carros[]{
    return this.receberCarros;
  }

  getById(id: number){
    return this.receberCarros[id-1]
  }

  getLastid(){
    return this.receberCarros[this.getQtd()-1].id
  }

  getQtd(){
    return this.receberCarros.length
  }
  
  getNextId(){
    return this.getLastid()+1
  }

  add(carro){
    this.receberCarros.push(carro)
    sessionStorage.setItem('carros',JSON.stringify(this.receberCarros))
  }
  
  excluir(){
    alert("teste")
  }

}
