import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CarrosService } from '../carros.service';
import { Carros } from '../carros';
import { CARROS } from '../mock-carros';

@Component({
  selector: 'app-detalhes',
  templateUrl: './detalhes-carros.component.html',
  styleUrls: ['./detalhes-carros.component.css']
})
export class DetalhesCarrosComponent implements OnInit {

  carro = new Carros()
  idcarro: any 
  carros: any

  constructor(private route: ActivatedRoute, private CarrosService: CarrosService) {
    this.idcarro = this.route.snapshot.params['idcarro'];
    this.carros = CARROS
    var carro = this.CarrosService.getById(this.idcarro);
  

    if(carro !== undefined){
      this.carro = carro
    }
  }

  ngOnInit() {
  }

  getGetParams() {
    return this.route.snapshot.queryParams;
  }
  
  excluir(){
    this.CarrosService.excluir()
  }
}
