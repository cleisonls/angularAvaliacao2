import { Component, OnInit } from '@angular/core';
import { Pessoas } from '../pessoas';
import { PessoasService } from '../pessoas.service';

@Component({
  selector: 'app-listar-pessoas',
  templateUrl: './listar-pessoas.component.html',
  styleUrls: ['./listar-pessoas.component.css']
})
export class ListarPessoasComponent implements OnInit {
  pessoa : Pessoas = {
    id: 0,
    nome:'',
    dataNascimento:'',
    idade: null,
    cidade:'',
    uf: '',
    empregado: null,
    altura: 0
  };
  

  constructor(private PessoasService: PessoasService) {
    this.pessoa.id = this.PessoasService.getNextId();
  } 

  ngOnInit() {
  }

  pessoas = this.PessoasService.getAll()

  onAdd(): void {
    this.PessoasService.add(this.pessoa)
    this.limpar()
  }

  limpar(): void {
    this.pessoa = new Pessoas();
    let number = this.PessoasService.getNextId()
    this.pessoa.id = number;
  }
  
  removerPessoa(id){
    this.PessoasService.removerPessoa(id)
    this.pessoas = this.PessoasService.getAll()
  }

  editarPessoa(id){
    this.pessoa = this.PessoasService.getById(id)
  }
}
