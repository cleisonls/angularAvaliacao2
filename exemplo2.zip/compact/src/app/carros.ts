export class Carros {
    id: number;
    marca: string;
    modelo: string;
    ano: string;
    placa: string;
}