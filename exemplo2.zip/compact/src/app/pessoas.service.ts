import { Injectable } from '@angular/core';
import { PESSOAS } from './mock-pessoas';
import { Pessoas } from './pessoas';
import { TouchSequence } from 'selenium-webdriver';

@Injectable({
  providedIn: 'root'
})
export class PessoasService {

  constructor() {
    this.getPessoasDatabase();
  }

  getPessoasDatabase(){
    var session = sessionStorage.getItem('pessoas');
    console.log(session);
    if(session === null){
      this.lpessoa = PESSOAS
      sessionStorage.setItem('pessoas',JSON.stringify(this.lpessoa))
    }else{
      this.lpessoa = JSON.parse(session)
    }
  }

  lpessoa: Pessoas[];

  getAll(): Pessoas[]{
    return this.lpessoa;
  }

  getById(id: number){
    return this.lpessoa[this.getPosicao(id)]
  }

  getLastid(){
    return this.getQtd() < 1 ? 0 : this.lpessoa[this.getQtd()-1].id
  }

  getPosicao(id){
    var posicao = null
    this.lpessoa.map(function(valores,chave){
      if (valores.id == id){
        posicao = chave
      }
    })
    return posicao
  }

  getQtd(){
    return this.lpessoa.length
  }

  getNextId(){
    return this.getLastid()+1
  }

  add(pessoa){
    this.lpessoa.push(pessoa)
    sessionStorage.setItem('pessoas',JSON.stringify(this.lpessoa))
  }

  removerPessoa(id){
    this.lpessoa.splice(this.getPosicao(id),1)
    sessionStorage.setItem('pessoas',JSON.stringify(this.lpessoa))
  }


}
